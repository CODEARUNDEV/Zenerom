# PrimeFolio - High-Fidelity Website Replica

A pixel-perfect, production-ready, fully responsive reverse-engineered replica of the **PrimeFolio** portfolio template ([https://primefolio.webflow.io/](https://primefolio.webflow.io/)).

---

## 🚀 How to Run the Website

Because this project is built using vanilla HTML5, CSS3, and JavaScript, it can be served using any local web server or viewed directly in modern browsers.

### Option 1: Built-in Node.js Static Server (Recommended)
This workspace includes a zero-dependency static server `server.js` configured with proper MIME types for MP4 video streaming, TTF fonts, and SVG icons.

```bash
# Start the local server
node server.js
```
Then open your browser at:
```
http://localhost:3333/
```

### Option 2: Apache / XAMPP
Since this project is located in `e:\xampp\htdocs\zenweb`, you can start the Apache server via the XAMPP Control Panel and navigate to:
```
http://localhost/zenweb/
```

### Option 3: Python HTTP Server
```bash
python -m http.server 3000
```
Then open `http://localhost:3000/`.

---

## 📁 Project Architecture & Asset Structure

The codebase is organized cleanly without bloated frameworks or chaotic inline code:

```
zenweb/
├── index.html                   # Semantic HTML5 markup with local asset references
├── css/
│   ├── style.css                # Typography (@font-face Inter Display), variables, layout
│   ├── responsive.css           # Desktop, tablet (991px), and mobile (767px, 479px) media queries
│   ├── animations.css           # Keyframes, hover interactions, marquee loops, transitions
│   └── lenis.css                # Smooth-scroll container styles
├── js/
│   ├── main.js                  # App initialization, Lenis setup, navbar scroll detector, video toggle
│   ├── interactions.js          # Sidemenu drawer, FAQ accordion, link hover animations
│   ├── animations.js            # Scroll reveals, rolling counter observer, CTA pulsing avatars
│   ├── lenis.min.js             # Local Lenis smooth scroll library
│   └── gsap.min.js              # Local GSAP library
├── assets/
│   ├── fonts/                   # Inter Display font weights (300, 400, 500, 600, 700, 900)
│   ├── images/                  # All high-resolution showcase webp/png project graphics
│   ├── icons/                   # Vector SVGs (brand logos, arrows, status indicators, badges)
│   └── videos/                  # Background showcase video (1080p MP4) and fallback poster
├── server.js                    # Lightweight development HTTP server
└── README.md                    # Technical documentation and maintenance guide
```

---

## 🎨 Design & Animation Implementation

Every interaction and animation from the reference site has been inspected, extracted, and reproduced:

1. **Typography & Styling:**
   - Font family: `Inter Display` with 6 weights (`300`, `400`, `500`, `600`, `700`, `900`) bundled locally in `assets/fonts/`.
   - CSS Variables: Colors (`--black-900`, `--black-800`, `--black-600`, `--black-100`, `--black-50`, `--white`), radii (`--_border-radius---radius-l: 20px`), and modular spacing scales.

2. **Navigation & Sidemenu Drawer:**
   - Top navbar features a dynamic sticky header that hides on scroll-down and slides into view on scroll-up (`.navbar.nav-hidden`).
   - Clicking `+ Menu` smoothly reveals a full-height sidemenu drawer from the left with an `outExpo` 700ms easing curve and backdrop overlay.
   - Dual-text slide-up effect on navigation links: on hover, the top label translates Y `-100%` while the bottom label enters, accompanied by an animated underline slide.

3. **Hero Section & Showcase Video:**
   - Background video autoplay with a custom circular play/pause button that dynamically toggles play state and changes icons.
   - Live client avatar badge with 5-star rating overlay and client marquee.

4. **Work & Project Cards:**
   - Project cards feature a smooth zoom (`transform: scale(1.08)`) on hover.
   - The central floating **Discover** badge smoothly scales up from `0` to `1`.
   - Dual-arrow button micro-interaction: on hover, the first arrow translates up-right while the second enters from bottom-left.

5. **About Studio & Rolling Counters:**
   - An `IntersectionObserver` triggers the numeric counter roll-up (`4.9`, `100+`, `99%`) utilizing a customized cubic bezier curve: `cubic-bezier(0.785, 0.135, 0.15, 0.86)` over 2000ms.

6. **Interactive FAQ Accordion:**
   - Accordion toggles open and closed with a smooth max-height expansion.
   - Plus icon (`+`) rotates 45 degrees into an `✕` upon expansion.

7. **Continuous Infinite Marquees:**
   - Seamless infinite scrolling logos in the Hero, Value, and Founder sections with hover pause capability.

8. **CTA Floating Avatar Grid:**
   - 9 avatars configured with gentle floating keyframes (`floatGentle1` / `floatGentle2`) and hover zoom.

---

## 📱 Responsive Breakpoints

Exact responsive rules matching Webflow's design system:
- **Desktop:** `1440px` and `1280px` standard container layouts (`max-width: 1200px`).
- **Tablet (`max-width: 991px`):** Replaces desktop navigation links with the `+ Menu` drawer button, stacks dual-column grids into fluid vertical layouts.
- **Mobile Landscape (`max-width: 767px`):** Enables dedicated mobile work card list (`.work-cl-wrapper.mobile-on`), adjusts hero layout, typography clamp, and padding.
- **Mobile Portrait (`max-width: 479px`):** Full-width touch cards, 100% viewport drawer, responsive video height, and zero horizontal overflow.

---

## 📦 External Dependencies

- **None** from third-party networks at runtime. All assets, fonts, icons, videos, and libraries (`Lenis`, `GSAP`) are hosted locally in `assets/` and `js/`.
- Does not require Node modules or build steps (`npm run build` not needed).

---

## ✏️ How to Modify Content

- **Update Work Projects:** In [index.html](file:///e:/xampp/htdocs/zenweb/index.html), search for `<section class="section work">` and update the project titles, categories, and thumbnail images.
- **Modify FAQs:** Search for `<section class="section faq">` and edit questions inside `.faq-title-text` or answers inside `.faq-answer-paragraph`.
- **Change Social & Contact Links:** Search for `.footer-social-wrap` and `.menu-social-wrap`.
