# Current State Architecture & System Snapshot: Zenweb (Zenerom UAE)

> **Document Status**: Factual Snapshot  
> **Evaluation Date**: Current Workspace Reality  
> **Repository Root**: `e:\xampp\htdocs\zenweb`  

---

## 1. Project Purpose

Zenweb is the official web platform for **Zenerom UAE** (`zenerom.ae`), a Dubai-based digital growth, SEO, performance marketing, and technology agency headquartered at Burjuman Business Tower, Dubai, UAE. The application showcases agency services, client case studies, process methodology, company history/timeline, leadership and specialist teams, client testimonials, and business contact points.

---

## 2. Technology Stack

| Layer | Technology | Version / Specification | Source / Hosting |
|---|---|---|---|
| **Markup** | HTML5 | Semantic Webflow-derived DOM structure | Local (`index.html`, `about.html`) |
| **Styling** | Vanilla CSS3 | Custom Design Tokens, CSS Grid, 3D Transforms | Local (`css/style.css`, `responsive.css`, `animations.css`, `lenis.css`) |
| **Typography** | Inter Display | 6 Weights (Light 300, Regular 400, Medium 500, SemiBold 600, Bold 700, Black 900) | Local (`assets/fonts/InterDisplay-*.ttf`) |
| **Interactivity** | Vanilla ES6 JavaScript | Custom DOM event listeners & IntersectionObservers | Local (`js/main.js`, `interactions.js`, `animations.js`, `about.js`) |
| **Smooth Scroll** | Lenis | Inertial smooth scroll engine | Local (`js/lenis.min.js`) |
| **Animation Engine** | GSAP (GreenSock) | Core GSAP library | Local (`js/gsap.min.js`) |
| **Dev Server** | Node.js | v24.13.0 (zero-dependency `http` module) | Local (`server.js`, port 3333) |
| **Production Server** | Apache (XAMPP) | Apache 2.4+ with `mod_rewrite` via `.htaccess` | `e:\xampp\htdocs\zenweb` |
| **Database** | None | Not applicable | No database used |
| **Build Tools** | None | Zero build step (no Webpack, Vite, or PostCSS) | Raw static files |

---

## 3. Architecture & Directory Structure

The project is structured as a static multi-page application (MPA):

```
zenweb/
├── .htaccess                     # Apache clean URL routing configuration
├── README.md                     # Legacy template documentation guide
├── server.js                     # Zero-dependency Node.js HTTP dev server (port 3333)
├── index.html                    # Homepage (Hero, Works, Services, FAQ, CTA, Footer)
├── index.original.html           # Original template backup of homepage (91.5 KB)
├── about.html                    # About page (Video Hero, Process, Journey, Team, Newsletter)
├── about.html.bak                # Legacy backup of original Webflow about page (54.7 KB)
├── zenweb.zip                    # Static archive backup of workspace assets (15.3 MB)
│
├── ai/                           # AI project brain & documentation folder
│   ├── instructions.md           # Guidelines and rules for future AI agents
│   ├── decisions.md              # Chronological technical decisions record
│   ├── known-issues.md           # Verified bugs, technical debt, and risks
│   └── current-state.md          # Factual system snapshot (this document)
│
├── css/                          # Stylesheet layer
│   ├── style.css                 # Inter Display @font-face rules, CSS reset, baseline tokens
│   ├── responsive.css            # Responsive layout classes and Webflow breakpoint media queries
│   ├── animations.css            # Keyframe animations, 3D cards, timeline styles, team cards
│   └── lenis.css                 # Lenis smooth-scrolling wrapper styles
│
├── js/                           # Clientside JavaScript layer
│   ├── lenis.min.js              # Lenis smooth scrolling vendor library
│   ├── gsap.min.js               # GSAP core animation vendor library
│   ├── main.js                   # Lenis initialization, scroll navbar visibility, anchor navigation
│   ├── interactions.js           # Sidemenu drawer, FAQ accordion, capabilities hover, CTA avatar cycle
│   ├── animations.js             # Scroll reveal observer, rolling numbers, rotating subtitle stars
│   └── about.js                  # 3D fan-out Process mechanics, Journey timeline navigation
│
├── assets/                       # Static media layer (Total: ~32.16 MB)
│   ├── fonts/                    # 6 TrueType font weights of Inter Display (~2.34 MB)
│   ├── icons/                    # 68 SVG vector icons & partner/social marks (~0.26 MB)
│   ├── images/                   # 172 WebP and PNG raster graphics (~4.75 MB)
│   │   ├── team/                 # Leadership & specialist portraits
│   │   ├── timeline/             # Milestone imagery (2015, 2017, 2022, 2026)
│   │   └── clients/              # Client logo marquees
│   └── videos/                   # 6 MP4/WebM video clips and fallback posters (~24.81 MB)
│
└── node_modules/                 # Leftover unreferenced package (opentype.js)
```

---

## 4. Major Components & Features

### 4.1 Global Navigation (`.header`, `.navbar`, `.sidemenu`)
- **Sticky Auto-Hiding Navbar**: Hides when scrolling down past 150px (`.nav-hidden`), reappears when scrolling up, and applies frosted shadow background (`.nav-scrolled`) past 50px.
- **Sidemenu Drawer**: Full-height drawer sliding from the left with an easing curve, triggered by `.menu-open-block` (`+ Menu`) and closed via `.manu-close-block` (`✕`), backdrop click, or ESC key. Disables body scrolling and halts Lenis while active.
- **Dual-Text Hover Interaction**: Nav links contain stacked text spans (`.nav-link-text`); on hover, the top span shifts Y `-100%` while the bottom span enters from below with an underline bar animation.

### 4.2 Homepage (`index.html`)
- **Hero Section**: Rating badge with avatars, agency headline, dual CTA buttons, and an infinite marquee of client logos.
- **Work Showcase (`.section.work`)**: Interactive project cards with scale zoom on hover (`transform: scale(1.08)`), floating centered **Discover** badge, and dual-arrow micro-animations.
- **Services & Capabilities Accordion (`.section.capabilities`)**: Dual-mode interaction allowing desktop hover switching (`mouseenter`/`mouseleave`) and touch-tap toggling (`.is-active`).
- **Interactive FAQ Accordion (`.section.faq`)**: Smooth max-height expansion with 45-degree rotation of the plus icon (`+` to `✕`).
- **Rolling Numerical Counters**: Triggered via `IntersectionObserver` using a cubic-bezier curve (`4.9`, `100+`, `99%`).
- **Interactive CTA Avatar Matrix (`.section.cta`)**: 9 floating avatars running a continuous background group cycle (500ms intervals) and 60fps cursor parallax smoothing.

### 4.3 About Page (`about.html`)
- **Video Hero Section (`.abou-hero`)**: Background video (`bungee-about-hero.mp4` / `.webm`) with poster fallback and client marquee.
- **3D Fan-Out Process Section (`.section.process`)**:
  - 500vh scroll track containing a sticky container (`top: 80px`).
  - 5 cards (`Discover`, `Strategy`, `Execution`, `Optimize`, `Scale`) fan out from 20% to 50% scroll travel, then execute sequential 3D Y-axis flips (0° to 180°) from 50% to 80% scroll travel.
  - Generous `140px` bottom section padding and `40px` sticky buffer for clean separation before the next section.
- **"Our Journey" Timeline Section (`.section_timeline`)**:
  - Dark-themed section (`#0d0f12`) placed directly before the team section.
  - Sticky sidebar with `• OUR JOURNEY` pill and interactive year links (`2015`, `2017`, `2022`, `2026`).
  - 4 milestone cards with WebP photography and descriptions.
  - Smooth Lenis scroll navigation on year click (`offset: -100px`) and `IntersectionObserver` scroll spy toggling `.is-active`.
- **Leadership & Specialist Team Section (`.section_team`)**:
  - Dedicated Leadership & Partners grid with individual LinkedIn and WhatsApp direct links.
  - Specialist Co-Workers grid showcasing experience badges.

---

## 5. Backend, APIs, Database & External Services

| Dimension | Current State | Verification Status |
|---|---|---|
| **Backend Services** | None. Zero server-side runtime code outside static file streaming in `server.js`. | **Verified** |
| **Database** | None. No SQL, NoSQL, ORM, or database connections exist. | **Verified** |
| **API Endpoints** | None. No REST, GraphQL, or RPC endpoints implemented or consumed. | **Verified** |
| **Authentication** | None. All pages are publicly accessible static resources. | **Verified** |
| **External CDNs** | Zero runtime dependencies. All CSS, JS, fonts, and images are local. | **Verified** |
| **Forms Handling** | Client-side only. Newsletter form intercepts submit via JavaScript (`e.preventDefault()`) and shows success DOM state without network submission. | **Verified** |
| **External Integrations** | Direct hyperlinks only (WhatsApp API `wa.me`, LinkedIn profiles, Google Maps coordinates). | **Verified** |

---

## 6. Environment & Configuration

- **Environment Files**: None (`.env` does not exist).
- **Configuration Files**:
  - `.htaccess`: Apache URL rewriting rules.
  - `server.js`: Contains local port definition (`const PORT = 3333;`).
- **Dependencies (`node_modules/`)**:
  - `opentype.js` (installed on disk, but unreferenced and unused).

---

## 7. How the Application Runs

### Development Execution:
1. **Node.js**:
   ```bash
   node server.js
   ```
   Listens on `http://localhost:3333/`.
2. **Apache / XAMPP**:
   Accessible via `http://localhost/zenweb/` when Apache is running in XAMPP.
3. **Python HTTP Server**:
   ```bash
   python -m http.server 3000
   ```

### Build Pipeline:
- **None**: No build command exists or is needed. Modifying files in `css/`, `js/`, or `.html` updates the website immediately upon browser refresh.

---

## 8. Current Limitations & Gaps

1. **Unimplemented Subpages**: Primary links such as `/contact`, `/careers`, `/work`, `/privacy-policy`, and `/terms-conditions` do not have corresponding HTML files in the project, leading to 404 responses when clicked.
2. **Mock Form Processing**: Newsletter submission does not transmit email data to any destination.
3. **Repository Version Control**: The project workspace is not currently initialized as a Git repository.
4. **Documentation Sync**: `README.md` still reflects the PrimeFolio upstream template rather than Zenerom UAE.
