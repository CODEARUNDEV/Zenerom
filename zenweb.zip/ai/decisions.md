# Technical Decisions Log: Zenweb (Zenerom UAE)

This document records the verifiable technical decisions embodied in the codebase, documenting their current implementation, affected components, trade-offs, and evidence.

---

## Decision 1: Pure Vanilla Stack Without Build Tools or Transpilers
- **Decision**: Build the application using standard HTML5, Vanilla CSS3, and ES6 JavaScript without Node build tools (no Webpack, Vite, PostCSS, or Babel).
- **Why it appears to have been made**: Eliminates build-step overhead, allows instantaneous editing and previewing in Apache (XAMPP) or any static file server, and avoids build-dependency churn.
- **Current implementation**: Raw HTML files (`index.html`, `about.html`) directly link plain CSS files in `css/` and script files in `js/`.
- **Files/components affected**: Entire project root, `css/`, `js/`.
- **Known trade-offs**: No CSS preprocessor (SCSS) or bundling/minification pipeline for custom styles; cache-busting must be managed manually via query parameters (`?v=26`).
- **Evidence/source in project**: Absence of `package.json`, absence of build scripts, direct `<link>` and `<script>` tags in `index.html` and `about.html`, explicit note in `README.md` lines 7–12 & 113–116.
- **Status of reason**: **Verified** (Documented directly in `README.md`).

---

## Decision 2: 100% Local Hosting of Runtime Assets and Libraries
- **Decision**: Bundle all external vendor libraries (`Lenis`, `GSAP`), fonts (`Inter Display`), vector icons, and video files locally in `assets/` and `js/`, eliminating runtime CDN dependencies.
- **Why it appears to have been made**: Ensures the website operates entirely offline (e.g., local XAMPP environments), avoids third-party CDN latency, eliminates third-party tracking/cookie complications, and prevents breaking changes from external CDN updates.
- **Current implementation**: 
  - `js/lenis.min.js` and `js/gsap.min.js` stored locally.
  - `assets/fonts/InterDisplay-*.ttf` served locally with `@font-face` rules in `css/style.css`.
  - 172 images and 68 SVG icons stored in `assets/`.
- **Files/components affected**: `js/`, `assets/`, `css/style.css`.
- **Known trade-offs**: Increases project repository size (~32 MB total assets); requires manual updates when library updates are desired.
- **Evidence/source in project**: Code inspection shows 0 external network requests during runtime; `README.md` lines 113–116 states: *"None from third-party networks at runtime. All assets, fonts, icons, videos, and libraries (Lenis, GSAP) are hosted locally"*.
- **Status of reason**: **Verified**.

---

## Decision 3: Custom Zero-Dependency Node.js Development Server (`server.js`)
- **Decision**: Include a standalone Node.js script using only Node's built-in `http`, `fs`, and `path` modules to serve the static site locally on port 3333.
- **Why it appears to have been made**: Provides an out-of-the-box local testing server for developers who do not have Apache or Python installed, with built-in MIME types for WebP, MP4, and font streaming, plus automatic extensionless `.html` file resolution.
- **Current implementation**: `server.js` contains a 58-line HTTP server handling extension mapping, 404 responses, and file streaming.
- **Files/components affected**: `server.js`.
- **Known trade-offs**: Minimal static server with no hot module reloading (HMR), no HTTPS, and no dynamic API routing.
- **Evidence/source in project**: `server.js` source code; `README.md` Option 1 (lines 11–21).
- **Status of reason**: **Verified**.

---

## Decision 4: Webflow HTML/CSS Architecture Reverse-Engineering
- **Decision**: Extract, clean, and structure HTML and CSS from Webflow templates (specifically PrimeFolio and Euphoria) to construct production-ready static pages.
- **Why it appears to have been made**: Leverages high-fidelity agency design systems, micro-interactions, responsive grids, and design tokens while running on an independent, non-Webflow hosting setup.
- **Current implementation**: 
  - Markup retains Webflow data attributes (`data-wf-page`, `data-w-id`, `w-container`, `w-layout-blockcontainer`).
  - Webflow IX2 animations are faithfully reproduced in vanilla JavaScript (`interactions.js`, `animations.js`, `about.js`).
- **Files/components affected**: `index.html`, `about.html`, `css/responsive.css`, `css/animations.css`, `js/interactions.js`.
- **Known trade-offs**: Residual Webflow attributes and unused classes remain in the HTML; CSS files are extensive (`responsive.css` is ~134KB).
- **Evidence/source in project**: Comment headers in `index.html` and `about.html` (`This site was created in Webflow...`), Webflow class hierarchies, `about.html.bak` referencing `primefolio.webflow.io`.
- **Status of reason**: **Verified** (Documented in `README.md` line 3).

---

## Decision 5: Dual-Path Smooth Scrolling (Lenis + GSAP Integration)
- **Decision**: Implement Lenis for physics-based inertial scrolling with fallback to native browser smooth scrolling, integrating scroll offsets for sticky headers.
- **Why it appears to have been made**: Delivers a luxury, polished agency aesthetic with consistent smooth scrolling across different browsers and input devices (mouse wheel, trackpad).
- **Current implementation**:
  - `js/lenis.min.js` instantiated in `js/main.js` and attached to `window.lenis`.
  - RAF loop drives Lenis updates.
  - Anchor link clicks calculate target positions and execute `window.lenis.scrollTo(targetEl, { offset: -80 })`.
  - Sidemenu drawer halts Lenis (`window.lenis.stop()`) on open and resumes it (`window.lenis.start()`) on close to prevent background page scroll.
- **Files/components affected**: `js/main.js`, `js/interactions.js`, `js/about.js`, `css/lenis.css`.
- **Known trade-offs**: Inertial scrolling overrides native OS scrolling physics, which may not appeal to all users; requires explicit offset management for sticky headers.
- **Evidence/source in project**: `js/main.js` lines 7–27 & 83–99; `js/interactions.js` lines 17 & 24.
- **Status of reason**: **Verified**.

---

## Decision 6: Rebranding from PrimeFolio to Zenerom UAE Agency
- **Decision**: Transition the content, metadata, schema markup, and imagery from the generic PrimeFolio portfolio template to Zenerom UAE (a Dubai-based digital growth & marketing agency).
- **Why it appears to have been made**: Customizing the template for client delivery / commercial agency production use.
- **Current implementation**:
  - `index.html` title: *"Zenerom - Digital Growth & Marketing Agency Dubai"*.
  - `about.html` title: *"About Zenerom | Dubai Digital Marketing & Technology Team"*.
  - Partner logos, Dubai headquarters address (`Burjuman Business Tower, Office 929, Dubai, UAE`), contact phone/WhatsApp lines (+971), and real team members added.
- **Files/components affected**: `index.html`, `about.html`, `assets/images/team/`, `assets/images/clients/`.
- **Known trade-offs**: Some residual mentions of "PrimeFolio" remain in `README.md` and in older script comments (`main.js`, `interactions.js`).
- **Evidence/source in project**: Meta tags, JSON-LD schema in `index.html`, team biographies and partner marquees in `about.html`.
- **Status of reason**: **Verified**.

---

## Decision 7: Scroll-Driven 3D Process Animation via Client-Side Calculation
- **Decision**: Implement a 500vh sticky scroll section where 5 cards fan out in 3D perspective and flip sequentially as the user scrolls, driven by `getBoundingClientRect()` in `requestAnimationFrame`.
- **Why it appears to have been made**: Replicates Webflow IX2's scroll-linked keyframe animation without importing the heavy proprietary Webflow JS engine.
- **Current implementation**:
  - `.section.process` set to `height: 500vh;` with a sticky child `.process-sticky-wrap`.
  - `updateProcessScroll()` in `js/about.js` computes scroll progress `(windowHeight - rect.top) / totalTravel`.
  - Fan-out occurs between 20% and 50% progress; card 3D Y-rotations (0° to 180°) trigger progressively from 50% to 80%.
  - Clicking cards directly toggles `.flipped` class for direct accessibility.
- **Files/components affected**: `about.html`, `css/animations.css` lines 936–1135, `js/about.js` lines 70–160.
- **Known trade-offs**: High scroll height (500vh) requires substantial mouse wheel travel; mobile viewports disable 3D transformations and render a 2-column grid.
- **Evidence/source in project**: `js/about.js` lines 90–160; `css/animations.css` lines 936–1135.
- **Status of reason**: **Verified**.

---

## Decision 8: Euphoria Template "Our Journey" Timeline Section Integration
- **Decision**: Add a dark-themed milestone timeline section (`.section_timeline`) with a sticky year navigation sidebar (`2015`, `2017`, `2022`, `2026`) and milestone cards positioned immediately before the "Our team" section.
- **Why it appears to have been made**: User request to mirror the design from `https://euphoria-template.webflow.io/about-v3` to communicate company history and milestones.
- **Current implementation**:
  - Left column: sticky sidebar with `• OUR JOURNEY` pill, heading, and year buttons with border indicators.
  - Right column: dark cards (`#1a1d21`) with locally downloaded WebP images (`assets/images/timeline/`).
  - Interactive Lenis click-to-scroll navigation and `IntersectionObserver` scroll spy toggling `.is-active`.
- **Files/components affected**: `about.html`, `css/animations.css` lines 1850–2070, `js/about.js` lines 284–328, `assets/images/timeline/`.
- **Known trade-offs**: Introduces a dark section (`#0d0f12`) between two light sections (`var(--white)` Process and `#f5f3ee` Team).
- **Evidence/source in project**: Git/conversation records; `about.html` lines 7–69; `css/animations.css` lines 1850–2070.
- **Status of reason**: **Verified**.

---

## Decision 9: Spacing & Section Buffer Decoupling
- **Decision**: Apply explicit `padding-bottom: 140px;` to `.section.process` and `padding-bottom: 40px;` to `.process-sticky-wrap` on desktop, plus `padding-bottom: 120px !important;` on mobile.
- **Why it appears to have been made**: Without this padding, the 5 Process cards sat directly on the color boundary separating the white section from the dark Journey section (~30px gap), creating visual cramping.
- **Current implementation**: CSS padding declarations in `css/animations.css`.
- **Files/components affected**: `css/animations.css` lines 940–955 & 1115–1125.
- **Known trade-offs**: Adds ~180px of white space below the cards before the dark section starts.
- **Evidence/source in project**: `css/animations.css` commit diff; user request in conversation history.
- **Status of reason**: **Verified**.

---

## Decision 10: Extensionless HTML Clean URLs
- **Decision**: Configure Apache (`.htaccess`) and the local Node dev server (`server.js`) to resolve `.html` files without requiring the `.html` extension in the URL bar (e.g., `/about` resolves to `about.html`).
- **Why it appears to have been made**: Standard modern web practice for cleaner URLs and SEO consistency.
- **Current implementation**:
  - `.htaccess`: Apache `mod_rewrite` rule checking `%{REQUEST_FILENAME}.html -f` and rewriting to `$1.html`.
  - `server.js`: Node `fs.existsSync(filePath + '.html')` check.
- **Files/components affected**: `.htaccess`, `server.js`.
- **Known trade-offs**: Links in HTML that use explicit `.html` (e.g., `about.html`) vs extensionless (`/about`) can create minor inconsistencies if not standardized.
- **Evidence/source in project**: `.htaccess` source code; `server.js` lines 31–33.
- **Status of reason**: **Verified**.
