/**
 * Zenerom UAE - Single Blog Article Controller (js/blog-single.js)
 * Hydrates standalone article reader, builds dynamic TOC, sets SEO meta,
 * and renders related category articles.
 */

(function () {
  'use strict';

  if (typeof BLOGS_DATA === 'undefined' || !Array.isArray(BLOGS_DATA)) {
    console.error('Zenerom Blog Single: BLOGS_DATA not found.');
    return;
  }

  // Helper
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  async function init() {
    const params = new URLSearchParams(window.location.search);
    const slug = params.get('slug') || 'parasite-seo-dubai-brands';

    // Find summary entry
    const postSummary = BLOGS_DATA.find(p => p.slug === slug) || BLOGS_DATA[0];
    if (!postSummary) return;

    // Load full post data
    let fullPost = null;
    try {
      const res = await fetch('data/blogs-full.json');
      if (res.ok) {
        const fullDict = await res.json();
        fullPost = fullDict[slug] || fullDict[postSummary.slug];
      }
    } catch (e) {
      console.warn('Could not fetch blogs-full.json:', e);
    }

    const post = fullPost || postSummary;

    // Update SEO & Document Title
    document.title = `${post.seoTitle || post.title} | Zenerom Dubai`;
    
    const metaDesc = document.getElementById('singleBlogMetaDesc');
    if (metaDesc) metaDesc.setAttribute('content', post.seoDesc || post.excerpt);

    const ogTitle = document.getElementById('singleBlogOgTitle');
    if (ogTitle) ogTitle.setAttribute('content', post.seoTitle || post.title);

    const ogDesc = document.getElementById('singleBlogOgDesc');
    if (ogDesc) ogDesc.setAttribute('content', post.seoDesc || post.excerpt);

    const ogImg = document.getElementById('singleBlogOgImage');
    if (ogImg) ogImg.setAttribute('content', post.image);

    const canonicalEl = document.getElementById('singleBlogCanonical');
    if (canonicalEl) canonicalEl.setAttribute('href', post.canonical || window.location.href);

    // Update Hero elements
    const breadcrumbEl = document.getElementById('singleBlogBreadcrumb');
    if (breadcrumbEl) breadcrumbEl.textContent = post.title;

    const catEl = document.getElementById('singleBlogCategory');
    if (catEl) catEl.textContent = post.category;

    const readTimeEl = document.getElementById('singleBlogReadingTime');
    if (readTimeEl) readTimeEl.textContent = `• ${post.readingTime}`;

    const dateEl = document.getElementById('singleBlogDate');
    if (dateEl) dateEl.textContent = `• ${post.formattedDate}`;

    const headingEl = document.getElementById('singleBlogHeading');
    if (headingEl) headingEl.textContent = post.title;

    const authorNameEl = document.getElementById('singleBlogAuthorName');
    if (authorNameEl) authorNameEl.textContent = post.author;

    const featuredImgEl = document.getElementById('singleBlogFeaturedImg');
    if (featuredImgEl) {
      featuredImgEl.src = post.image;
      featuredImgEl.alt = post.title;
    }

    // Hydrate Share links
    const currentUrl = encodeURIComponent(post.canonical || window.location.href);
    const postTitle = encodeURIComponent(post.title);
    const shareWa = document.getElementById('singleBlogShareWa');
    if (shareWa) shareWa.href = `https://wa.me/?text=${postTitle}%20${currentUrl}`;

    const shareIn = document.getElementById('singleBlogShareIn');
    if (shareIn) shareIn.href = `https://www.linkedin.com/sharing/share-offsite/?url=${currentUrl}`;

    const sideWa = document.getElementById('singleBlogSideWa');
    if (sideWa) {
      sideWa.href = `https://wa.me/971563996631?text=${encodeURIComponent(`Hello Zenerom, I was reading your insight "${post.title}" and would like to consult on our business strategy.`)}`;
    }

    // Render Article HTML Content
    const contentEl = document.getElementById('singleBlogContent');
    if (contentEl) {
      if (post.content && post.content.trim().length > 0) {
        contentEl.innerHTML = post.content;
      } else {
        contentEl.innerHTML = `
          <p style="font-size:1.2rem; line-height:1.8; color:#334155;">${escapeHtml(post.excerpt)}</p>
          <p style="margin-top:1.5rem; color:#64748b;">
            This executive analysis was formulated by Zenerom's Dubai growth team. For comprehensive architectural consultation or to review your current funnel performance, reach out directly to our strategy squad.
          </p>
        `;
      }
    }

    // Build Dynamic Table of Contents from headings
    buildTableOfContents(contentEl);

    // Render 3 Related Articles
    renderRelatedArticles(post);

    // Injected Schema Graph
    injectSchemaGraph(post);
  }

  function buildTableOfContents(contentEl) {
    const tocList = document.getElementById('singleBlogTocList');
    if (!tocList || !contentEl) return;

    const headings = contentEl.querySelectorAll('h2, h3');
    if (headings.length === 0) {
      const sidebar = document.querySelector('.blog-toc-card');
      if (sidebar) sidebar.style.display = 'none';
      return;
    }

    let tocHtml = '';
    headings.forEach((heading, idx) => {
      const id = heading.id || `section-heading-${idx + 1}`;
      heading.id = id;
      const text = heading.textContent.trim();
      const isSub = heading.tagName.toLowerCase() === 'h3';
      tocHtml += `
        <li>
          <a href="#${id}" class="blog-toc-link" style="${isSub ? 'padding-left:0.75rem; font-size:0.8125rem;' : ''}">
            ${escapeHtml(text)}
          </a>
        </li>
      `;
    });

    tocList.innerHTML = tocHtml;

    // Smooth scroll for TOC links
    tocList.querySelectorAll('.blog-toc-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').slice(1);
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          const headerOffset = 100;
          const elementPosition = targetEl.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
        }
      });
    });
  }

  function renderRelatedArticles(currentPost) {
    const gridEl = document.getElementById('singleBlogRelatedGrid');
    if (!gridEl) return;

    // Find posts in same category, exclude current
    let related = BLOGS_DATA.filter(p => p.category === currentPost.category && p.slug !== currentPost.slug);
    if (related.length < 3) {
      const others = BLOGS_DATA.filter(p => p.slug !== currentPost.slug && !related.includes(p));
      related = related.concat(others);
    }
    related = related.slice(0, 3);

    const cardsHtml = related.map(p => `
      <article class="blog-card" onclick="window.location.href='blog-single.html?slug=${p.slug}'">
        <div class="blog-card-media">
          <img src="${p.image}" alt="${escapeHtml(p.title)}" class="blog-card-img" loading="lazy" />
        </div>
        <div class="blog-card-body">
          <div class="blog-card-topline">
            <span class="blog-category-pill">${escapeHtml(p.category)}</span>
            <span class="blog-time-pill">${escapeHtml(p.readingTime)}</span>
          </div>
          <h3 class="blog-card-title">${escapeHtml(p.title)}</h3>
          <p class="blog-card-excerpt">${escapeHtml(p.excerpt)}</p>
          <div class="blog-card-footer">
            <div class="blog-card-author">
              <img src="assets/images/Fav.png" alt="${escapeHtml(p.author)}" class="blog-card-author-avatar" loading="lazy" />
              <div class="blog-card-author-meta">
                <span class="blog-card-author-name">${escapeHtml(p.author)}</span>
                <span class="blog-card-author-date">${escapeHtml(p.formattedDate)}</span>
              </div>
            </div>
            <div class="blog-read-circle" aria-label="Read ${escapeHtml(p.title)}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
              </svg>
            </div>
          </div>
        </div>
      </article>
    `).join('');

    gridEl.innerHTML = cardsHtml;
  }

  function injectSchemaGraph(post) {
    const schemaScript = document.getElementById('singleBlogSchema');
    if (!schemaScript) return;

    const schemaObj = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "headline": post.title,
      "description": post.seoDesc || post.excerpt,
      "image": post.image,
      "datePublished": post.date,
      "dateModified": post.date,
      "author": {
        "@type": "Person",
        "name": post.author
      },
      "publisher": {
        "@type": "Organization",
        "name": "Zenerom Digital Marketing Agency Dubai",
        "url": "https://zenerom.ae/",
        "logo": {
          "@type": "ImageObject",
          "url": "https://zenerom.ae/wp-content/uploads/2025/01/cropped-zen-logo-03.png"
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": post.canonical || window.location.href
      }
    };

    schemaScript.textContent = JSON.stringify(schemaObj, null, 2);
  }

  document.addEventListener('DOMContentLoaded', init);
})();
