/**
 * main.js - Core application initialization and setup
 * PrimeFolio Website Replica
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initialize Lenis Smooth Scroll
  let lenis = null;
  if (typeof Lenis !== 'undefined') {
    lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    function raf(time) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);
    window.lenis = lenis;
  }

  // 2. Navbar Hide/Show on Scroll Direction
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    let lastScrollY = window.scrollY;
    let ticking = false;

    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const currentScrollY = window.scrollY;

          // Add blur / background shadow when scrolled past top
          if (currentScrollY > 50) {
            navbar.classList.add('nav-scrolled');
          } else {
            navbar.classList.remove('nav-scrolled');
          }

          // Hide on scroll down, show on scroll up (with a threshold)
          if (currentScrollY > lastScrollY && currentScrollY > 150) {
            navbar.classList.add('nav-hidden');
          } else if (currentScrollY < lastScrollY) {
            navbar.classList.remove('nav-hidden');
          }

          lastScrollY = currentScrollY;
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });
  }

  // 3. Hero Video Play/Pause Control
  const video = document.querySelector('.hero-video video');
  const videoControlBtn = document.querySelector('[data-w-bg-video-control="true"]');
  if (video && videoControlBtn) {
    const pauseSpan = videoControlBtn.querySelector('span:not([hidden])');
    const playSpan = videoControlBtn.querySelector('span[hidden]');

    videoControlBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (video.paused) {
        video.play();
        if (pauseSpan) pauseSpan.removeAttribute('hidden');
        if (playSpan) playSpan.setAttribute('hidden', '');
      } else {
        video.pause();
        if (pauseSpan) pauseSpan.setAttribute('hidden', '');
        if (playSpan) playSpan.removeAttribute('hidden');
      }
    });
  }

  // 4. Smooth Anchor Link Navigation with Lenis
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId && targetId !== '#') {
        const targetEl = document.querySelector(targetId);
        if (targetEl) {
          e.preventDefault();
          if (window.lenis) {
            window.lenis.scrollTo(targetEl, { offset: -80 });
          } else {
            targetEl.scrollIntoView({ behavior: 'smooth' });
          }
        }
      }
    });
  });
});
