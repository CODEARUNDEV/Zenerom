/* ==========================================================================
   work.js - Interactive Mechanics for Zenerom Work & Case Studies Page
   Zenerom UAE Digital Marketing & Technology Agency
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initWorkFilter();
  initCaseStudyModal();
});

// Comprehensive Case Studies Database derived from https://zenerom.ae/case-study/
const CASE_STUDIES_DATA = {
  'florkett-seo': {
    category: 'E-Commerce & SEO',
    client: 'Florkett UAE (Flooring & Interior Solutions)',
    title: 'Florkett UAE: 412% Organic Revenue Growth & E-Commerce Scale',
    metrics: [
      { num: '+412%', lbl: 'Organic Revenue Surge' },
      { num: 'Top 3', lbl: 'Flooring Keywords in UAE' },
      { num: '3.8x', lbl: 'Inbound Return on Ad Spend' }
    ],
    challenge: 'Florkett faced low organic visibility for commercial flooring keywords in Dubai, poor category page crawl efficiency, weak internal linking, and zero ranking for high-intent B2B contractor search terms.',
    solution: [
      'Executed full-scale technical eCommerce SEO overhaul fixing 4,000+ crawl redirect loops',
      'Engineered structured category silos for Vinyl, SPC, LVT, Sports Flooring, and WPC Decking',
      'Implemented schema markup (Product, AggregateRating, BreadcrumbList) for rich snippet display',
      'Published comprehensive UAE flooring comparison guides and commercial installation standards'
    ],
    stack: ['Shopify Plus', 'Technical SEO', 'Schema.org', 'Ahrefs Enterprise', 'Looker Studio']
  },

  'laliga-ads': {
    category: 'Education & Paid Ads',
    client: 'LaLiga Academy UAE',
    title: 'LaLiga Academy: 934 Student Registrations at AED 44 CPL',
    metrics: [
      { num: '934', lbl: 'Verified Registrations' },
      { num: 'AED 44', lbl: 'Average Cost Per Lead' },
      { num: '31%', lbl: 'Conversion Rate Lift' }
    ],
    challenge: 'High cost-per-lead and wasted spend on broad generic sports keywords during competitive back-to-school registration windows across Dubai and Abu Dhabi.',
    solution: [
      'Rebuilt Google Search campaigns with strict negative keyword filtering and exact-match parent intent',
      'Deployed localized Performance Max asset groups targeting premium residential communities',
      'Built lightning-fast mobile enrollment landing funnels with direct WhatsApp integration',
      'Implemented offline conversion tracking syncing paid inquiries directly with academy CRM'
    ],
    stack: ['Google Ads', 'Performance Max', 'Custom Landing Pages', 'Zoho CRM', 'Looker Studio']
  },

  'dubai-renovation': {
    category: 'Interior Design & Meta Ads',
    client: 'RFS Remodeling Group Dubai',
    title: 'Dubai Renovation: 531 High-Ticket Villa Remodeling Leads',
    metrics: [
      { num: '531', lbl: 'Qualified Meta Inquiries' },
      { num: 'AED 1.8M', lbl: 'Contract Pipeline Value' },
      { num: '14.2%', lbl: 'Lead-to-Survey Rate' }
    ],
    challenge: 'Villa remodeling contracts in Dubai are high-ticket (AED 100k - 500k+). Conventional social media ads generated low-intent inquiries from tenants rather than qualifying luxury property owners.',
    solution: [
      'Created cinematic before-and-after video reels showcasing Palm Jumeirah and Dubai Hills villa renovations',
      'Configured hyper-targeted geo-fencing for freehold luxury communities in Dubai',
      'Designed an interactive multi-step renovation scope estimator qualifying budget before submission',
      'Automated instant WhatsApp lead notifications ensuring sales engineers respond within 5 minutes'
    ],
    stack: ['Meta Ads (Instagram & FB)', 'Video Production', 'Interactive Funnel', 'WhatsApp Cloud API']
  },

  'dewa-approvals': {
    category: 'Engineering & SEO',
    client: 'DEWA Approvals UAE',
    title: 'DEWA Approvals: +298% More Qualified Commercial Inquiries',
    metrics: [
      { num: '+298%', lbl: 'Commercial Inquiries Lift' },
      { num: '#1 Rank', lbl: 'for DEWA Electrical Approval' },
      { num: '< 90 Days', lbl: 'Ranking Velocity' }
    ],
    challenge: 'High competition from legacy MEP consultants and lack of structured information answering technical queries regarding governmental electricity and water authority submissions in Dubai.',
    solution: [
      'Architected topical authority content clusters covering substation approvals, load enhancements, and NOC filings',
      'Optimized Core Web Vitals to sub-second load times on mobile devices for on-site engineers',
      'Engineered localized schema markup establishing E-E-A-T credentials with Dubai municipal standards',
      'Built high-converting technical inquiry landing pages with instant document checklist downloads'
    ],
    stack: ['Technical SEO', 'Entity Optimization', 'Core Web Vitals', 'B2B Lead Funnels']
  },

  'statron-industrial': {
    category: 'Industrial & Web Dev',
    client: 'Statron Middle East',
    title: 'Statron Middle East: High-Capacity Industrial Web Platform',
    metrics: [
      { num: 'Sub-second', lbl: 'Global TTFB Speed' },
      { num: '100%', lbl: 'Mobile & Tablet UX Score' },
      { num: '+195%', lbl: 'B2B RFQ Submissions' }
    ],
    challenge: 'A legacy corporate site with fragmented technical specifications, poor mobile responsiveness, and sluggish catalog downloads preventing EPC contractors from submitting tender RFQs.',
    solution: [
      'Engineered custom, high-speed industrial website architecture with clean technical datasheets',
      'Designed intuitive parametric product filters for UPS systems, industrial rectifiers, and inverters',
      'Optimized multilingual content delivery across the Middle East with regional server caching',
      'Integrated streamlined RFP forms directly connecting procurement engineers with technical sales'
    ],
    stack: ['Custom Web Engineering', 'HTML5/Vanilla CSS', 'Responsive Grid', 'Fast CDN']
  },

  'farm-city': {
    category: 'Hospitality & Web Design',
    client: 'Farm City Dubai Restaurant',
    title: 'Farm City Dubai: Hospitality Web Experience & Table Bookings',
    metrics: [
      { num: '+340%', lbl: 'Online Table Reservations' },
      { num: '4.8★', lbl: 'Google Maps Authority' },
      { num: '12,000+', lbl: 'Monthly Menu Views' }
    ],
    challenge: 'Low visibility among Dubai diners and high third-party aggregator commissions eating away restaurant margins without building direct customer loyalty.',
    solution: [
      'Crafted an appetite-driven, modern restaurant web experience featuring immersive culinary imagery',
      'Engineered frictionless online table reservation system eliminating commission fees',
      'Optimized Google Business Profile and local culinary search pack across central Dubai districts',
      'Connected digital menus with real-time seasonal updates and private event inquiry routing'
    ],
    stack: ['Webflow / Vanilla Web', 'Table Booking Engine', 'Local SEO', 'Micro-Interactions']
  },

  'spearhead-training': {
    category: 'Education & Portals',
    client: 'Spearhead Training Gulf',
    title: 'Spearhead Training: Corporate Course Portal & Enrollments',
    metrics: [
      { num: '200+', lbl: 'Interactive Course Modules' },
      { num: '+185%', lbl: 'Corporate RFP Inquiries' },
      { num: 'Zero Latency', lbl: 'Dynamic Schedule Sync' }
    ],
    challenge: 'Managing over 200 corporate training courses across Dubai and Abu Dhabi on a clunky legacy system caused high bounce rates among HR and L&D corporate directors.',
    solution: [
      'Re-engineered full course taxonomy categorized by Leadership, Sales, HR, and Executive Skills',
      'Built dynamic course calendar with live dates, downloadable syllabi, and group booking discounts',
      'Optimized B2B corporate search visibility for certified management training in the UAE',
      'Synced inquiries with internal enterprise CRM for immediate corporate quotation generation'
    ],
    stack: ['Custom Portal Architecture', 'Course Database', 'B2B SEO', 'Enterprise CRM Sync']
  },

  'honest-healthcare': {
    category: 'Healthcare & Portals',
    client: 'Honest Home Health Care',
    title: 'Honest Home Health Care: Patient Portal & Care Bookings',
    metrics: [
      { num: '100%', lbl: 'DHA Regulatory Compliance' },
      { num: '+280%', lbl: 'Home Care Inquiries' },
      { num: '< 2 Mins', lbl: 'Nurse Booking Time' }
    ],
    challenge: 'Patients and families requiring urgent home nursing and elderly care in Dubai faced confusing booking steps and lacked clear information on DHA credentials and nurse qualifications.',
    solution: [
      'Built clean, empathetic healthcare website with strict DHA compliance and verified credentials',
      'Engineered multi-language patient intake flows for elderly care, post-operative support, and physiotherapy',
      'Implemented local Google Map pack dominance across residential Dubai and Northern Emirates',
      'Added direct 24/7 emergency WhatsApp triage button connected to medical coordinators'
    ],
    stack: ['Healthcare UX Design', 'DHA Compliance', 'Local Maps SEO', 'WhatsApp Cloud Desk']
  },

  'genyard-energy': {
    category: 'Energy & Industrial',
    client: 'Genyard Energy Systems',
    title: 'Genyard Energy: Power Generator Showcase & B2B Inquiries',
    metrics: [
      { num: '+220%', lbl: 'Industrial Quoting Inquiries' },
      { num: '45+ Units', lbl: 'Commercial Power Systems' },
      { num: '#1 Tier', lbl: 'Generator Rentals Search' }
    ],
    challenge: 'Industrial power generators require extensive engineering specifications (kVA ratings, fuel consumption, emissions) that were buried in unsearchable PDFs.',
    solution: [
      'Constructed comprehensive interactive generator catalog with parametric kVA filters',
      'Developed 1-click technical specification sheet generator for site engineers and contractors',
      'Targeted commercial industrial search queries across JAFZA, Dubai South, and Abu Dhabi KIZAD',
      'Created streamlined project rental quote builder with automated WhatsApp equipment dispatch'
    ],
    stack: ['Industrial Product Grid', 'Parametric Search', 'PDF Engine', 'B2B SEO']
  },

  'mai-events': {
    category: 'Events & Luxury',
    client: 'MAI Events Dubai',
    title: 'MAI Events Dubai: High-Impact VIP Corporate Event Portfolio',
    metrics: [
      { num: '3.5x', lbl: 'High-Ticket RFP Growth' },
      { num: '60+ VIP', lbl: 'Published Case Galleries' },
      { num: '98%', lbl: 'Client Delight Score' }
    ],
    challenge: 'A premier event management company in Dubai needed a luxury digital portfolio that matched the grandeur and sophistication of their multi-million dirham corporate and VIP events.',
    solution: [
      'Designed bespoke editorial portfolio featuring cinematic event imagery and fluid transitions',
      'Built interactive event concept visualizer for luxury weddings, corporate galas, and brand launches',
      'Targeted luxury event keywords in Dubai and GCC to attract international corporate planners',
      'Created confidential VIP proposal inquiry flow with NDA attachment capabilities'
    ],
    stack: ['Luxury UI/UX', 'GSAP Smooth Motion', 'Image Optimization', 'VIP Lead Intake']
  },

  'corp-creators': {
    category: 'Corporate Services',
    client: 'Corp Creators Dubai',
    title: 'Corp Creators: Mainland & Freezone Licensing Platform',
    metrics: [
      { num: '+310%', lbl: 'Business Setup Inquiries' },
      { num: '-45%', lbl: 'Customer Acquisition Cost' },
      { num: '24/7', lbl: 'Cost Calculator Funnel' }
    ],
    challenge: 'Dubai business setup is flooded with generic agencies. Corp Creators needed an authoritative platform that built instant trust with foreign investors and enterprise founders.',
    solution: [
      'Engineered interactive Dubai License Cost Calculator estimating fees across 30+ Freezones and Mainland',
      'Published in-depth investor guides on corporate tax compliance, Golden Visas, and banking setup',
      'Optimized organic search rankings for competitive commercial incorporation keywords',
      'Integrated real-time WhatsApp booking for senior legal and tax advisors'
    ],
    stack: ['Interactive Calculator', 'Corporate SEO', 'B2B Funnel', 'WhatsApp Desk']
  },

  'voltronix-seo': {
    category: 'Manufacturing & SEO',
    client: 'Voltronix UAE',
    title: 'Voltronix UAE: Commercial B2B SEO & Contractor Lead Engine',
    metrics: [
      { num: '+275%', lbl: 'Organic B2B Inquiries' },
      { num: '52 Keywords', lbl: 'Top 3 on Google UAE' },
      { num: 'AED 3.2M', lbl: 'Attributed Tender Volume' }
    ],
    challenge: 'Competing against multinational electrical manufacturers without a massive ad budget. The brand needed durable organic Page 1 rankings to capture contractor procurement orders.',
    solution: [
      'Mapped engineering procurement terms for electrical switchgear, transformers, and distribution panels',
      'Remediated site architecture, implementing schema graphs for industrial products and manufacturing facilities',
      'Acquired tier-1 GCC engineering citations and industry publication references',
      'Structured clear RFP request points directly on engineering specification pages'
    ],
    stack: ['Enterprise SEO', 'Industrial Entity Graphs', 'Looker Studio', 'B2B Funnel']
  },

  'tourzone-travel': {
    category: 'Travel & Web Platform',
    client: 'Tourzone UAE',
    title: 'Tourzone Travel: Digital Platform & Seamless Booking Flow',
    metrics: [
      { num: '+380%', lbl: 'Direct Tour Bookings' },
      { num: '1.2s', lbl: 'Page Experience Velocity' },
      { num: '4.9★', lbl: 'Traveler Review Rating' }
    ],
    challenge: 'International tourists and GCC weekenders struggled with complex checkout flows on standard travel portals, resulting in over 70% cart abandonment on desert safaris and Dubai city tours.',
    solution: [
      'Architected a sleek, mobile-first booking experience with instant date-picker and multi-currency pricing',
      'Integrated seamless Stripe and Apple Pay checkout with immediate WhatsApp ticket confirmation',
      'Engineered localized SEO landing pages for iconic UAE experiences (Burj Khalifa, Desert Safari, Marina Yachts)',
      'Optimized performance to achieve sub-second Core Web Vitals across 4G and 5G networks'
    ],
    stack: ['Custom Web App', 'Stripe / Apple Pay', 'Core Web Vitals', 'Tour Booking API']
  }
};

/**
 * 1. Category Filtering
 */
function initWorkFilter() {
  const filterBtns = document.querySelectorAll('.work-filter-btn');
  const workItems = document.querySelectorAll('.work-cl-item');

  if (!filterBtns.length || !workItems.length) return;

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');

      const filterVal = btn.getAttribute('data-filter');

      workItems.forEach((item) => {
        const itemCategory = item.getAttribute('data-category');
        if (filterVal === 'all' || itemCategory.includes(filterVal)) {
          item.classList.remove('is-filtered-out');
        } else {
          item.classList.add('is-filtered-out');
        }
      });
    });
  });
}

/**
 * 2. Case Study Quick-View Modal
 */
function initCaseStudyModal() {
  const modalBackdrop = document.getElementById('workModal');
  const closeBtn = document.getElementById('workModalClose');
  const workLinks = document.querySelectorAll('.work-single-block');

  if (!modalBackdrop) return;

  function closeModal() {
    modalBackdrop.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }

  modalBackdrop.addEventListener('click', (e) => {
    if (e.target === modalBackdrop) {
      closeModal();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalBackdrop.classList.contains('is-open')) {
      closeModal();
    }
  });

  workLinks.forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const studyId = link.getAttribute('data-study-id');
      const data = CASE_STUDIES_DATA[studyId];

      if (!data) return;

      // Populate Modal Fields
      document.getElementById('modalCategory').textContent = data.category;
      document.getElementById('modalClient').textContent = data.client;
      document.getElementById('modalTitle').textContent = data.title;

      // Metrics
      const metricsStrip = document.getElementById('modalMetricsStrip');
      metricsStrip.innerHTML = data.metrics.map(m => `
        <div class="work-modal-metric-block">
          <div class="work-modal-metric-num">${m.num}</div>
          <div class="work-modal-metric-lbl">${m.lbl}</div>
        </div>
      `).join('');

      // Challenge & Solution
      document.getElementById('modalChallenge').textContent = data.challenge;
      
      const solutionList = document.getElementById('modalSolutionList');
      solutionList.innerHTML = data.solution.map(s => `
        <li class="work-modal-list-item">
          <span style="color:var(--brand-flamingo, #f26934); font-weight:800;">✓</span>
          <span>${s}</span>
        </li>
      `).join('');

      // Tech Stack
      const techStack = document.getElementById('modalTechStack');
      techStack.innerHTML = data.stack.map(t => `
        <span class="work-tech-chip">${t}</span>
      `).join('');

      // WhatsApp Action Link
      const waBtn = document.getElementById('modalWhatsAppBtn');
      if (waBtn) {
        waBtn.href = `https://wa.me/971563996631?text=${encodeURIComponent('Hello Zenerom team, I am reviewing your case study on ' + data.client + ' (' + data.title + ') and would like to discuss a similar project.')}`;
      }

      // Open Modal
      modalBackdrop.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    });
  });
}
